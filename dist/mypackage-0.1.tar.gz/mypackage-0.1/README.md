# mypackage1
This library was created as an example of how to publish Python package

# building the package locally
'python setup.py sdist'

## installing this package from github
'pip install git+https://github.com/bokeimei/mypackage1'

## updating this package from gitHub

'pip install --upgrade git+https://github.com/bokeimei/mypackage1'
